# Nombre del algoritmo

Escribe una breve descripción del algoritmo como:

1. Complejidad temporal
2. Complejidad espacial
3. Aplicaciones
4. Nombre del creador
5. etc...

## Pasos

Describe el algoritmo como pasos simples, claros y entendibles.

## Ejemplo

Provee al algoritmo de datos de entrada de muestra.

## Implementación

Enlaces a sus implementaciones en lenguajes de programación.
NOTA: El enlace debe estar solo dentro de la carpeta algorithms.

## URL del video

Adjunta una URL a un video que explique el algoritmo.

## Otro

Cualquier otra información es siempre bienvenida y debería ser incluida en esta sección.
