
# Rust

# Strings
- [Palindrome Check](strings/palindrome/README.md)

# Sorting
- [Merge Sort](sorting/merge-sort/README.md)
