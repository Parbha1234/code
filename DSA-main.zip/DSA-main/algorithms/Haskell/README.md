# Haskell

## Strings
- [Palindrome Check](strings/palindrome.hs)
- [All subsequences](strings/sequence.hs)
