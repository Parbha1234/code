---
name: Proposal
about: Wanted to add Algorithm. This issue best for you...
title: '<!--Algorithm name]--> in <!--[language-->'
labels: Proposal
assignees: ''

---

## Information about Algorithm
<!--
i.e: What the given algorithm do and i.e. Type of algorithm array,stack
-->
(Type here)
### Have you read the [Contributing.md](https://github.com/MakeContributions/DSA/blob/main/CONTRIBUTING.md) and [Code of conduct](https://github.com/MakeContributions/DSA/blob/main/CODE_OF_CONDUCT.md)
<!-- Choose any one of them -->
- [ ] Yes
- [ ] No

## Other context
<!--
This is a competitive platform problem i.e. Hackerrank,Codechef,GeeksforGeeks,Leetcode,Codeforce 
-->
(Type here)
